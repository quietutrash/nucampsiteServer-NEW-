module.exports = {
    secretKey: "12345-67890-09876-54321",
    mongoUrl: "mongodb://localhost:27017/nucampsite",
    facebook: {
      clientId: "496792921540910",
      clientSecret: "7b65bd1f4afc6f435e02271c56cadd6e",
    },
  };